﻿<#
    AD Password Reset Tool (Single & Bulk)
    Fixed version:
    - Load specific domain and show OU tree
    - User search grid works and auto-selects first row
    - Reset works for selected user
    - Bulk reset supports multiple domains and logs results
    - Export includes domain
#>
<# 
    AD Password Reset Tool (Single & Bulk)
    Author: Md Abdullah
    PowerShell: Windows PowerShell 5.1
    Requires: RSAT ActiveDirectory
#>

$ErrorActionPreference = 'Stop'

# =========================
# Config
# =========================
$script:DefaultBulkPassword = ""
$script:BulkPasswordFile = if ($PSCommandPath) {
    Join-Path -Path (Split-Path -Parent $PSCommandPath) -ChildPath 'BulkPassword.txt'
} else {
    Join-Path -Path (Get-Location) -ChildPath 'BulkPassword.txt'
}

# ---------------------------
# Safety / Module Checks
# ---------------------------
function Ensure-ActiveDirectoryModule {
    if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
        throw "ActiveDirectory module not found. Install RSAT: Active Directory module for PowerShell."
    }
    Import-Module ActiveDirectory -ErrorAction Stop
}
Ensure-ActiveDirectoryModule

# ---------------------------
# WinForms Setup
# ---------------------------
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = "AD Password Reset Tool (Single & Bulk)"
$form.Size = New-Object System.Drawing.Size(1200, 900)
$form.StartPosition = "CenterScreen"
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)

# Panels
$panelTop = New-Object System.Windows.Forms.GroupBox
$panelTop.Text = "Connection"
$panelTop.SetBounds(10,10,1160,200)
$form.Controls.Add($panelTop)

$panelSearch = New-Object System.Windows.Forms.GroupBox
$panelSearch.Text = "Single User Search & Reset"
$panelSearch.SetBounds(10,220,1160,350)
$form.Controls.Add($panelSearch)

$panelBulk = New-Object System.Windows.Forms.GroupBox
$panelBulk.Text = "Bulk Reset"
$panelBulk.SetBounds(10,580,1160,260)
$form.Controls.Add($panelBulk)

# ---------------------------
# State
# ---------------------------
$script:SelectedDomain = $null
$script:Credential = $null
$script:DomainDN = $null
$script:BulkResults = New-Object System.Collections.Generic.List[object]

# ---------------------------
# Controls: Connection
# ---------------------------
$lblDomain = New-Object System.Windows.Forms.Label
$lblDomain.Text = "Domain:"
$lblDomain.Location = "15,25"
$panelTop.Controls.Add($lblDomain)

$cboDomain = New-Object System.Windows.Forms.ComboBox
$cboDomain.SetBounds(130,22,260,25)
$cboDomain.DropDownStyle = 'DropDownList'
$panelTop.Controls.Add($cboDomain)

$btnLoadDomains = New-Object System.Windows.Forms.Button
$btnLoadDomains.Text = "Load Domains"
$btnLoadDomains.SetBounds(400,22,135,25)
$panelTop.Controls.Add($btnLoadDomains)

# Credentials row
$chkUseCurrent = New-Object System.Windows.Forms.CheckBox
$chkUseCurrent.Text = "Use current credentials"
$chkUseCurrent.Checked = $true
$chkUseCurrent.Location = New-Object System.Drawing.Point(580, 22)
$chkUseCurrent.AutoSize = $true
$chkUseCurrent.Anchor = 'Top,Left'
$panelTop.Controls.Add($chkUseCurrent)

$btnChangeCred = New-Object System.Windows.Forms.Button
$btnChangeCred.Text = "Change Credentials"
$btnChangeCred.Location = New-Object System.Drawing.Point(800, 22)
$btnChangeCred.Size = New-Object System.Drawing.Size(190, 26)
$btnChangeCred.Enabled = $false
$btnChangeCred.Anchor = 'Top,Left'
$panelTop.Controls.Add($btnChangeCred)

$lblCredInfo = New-Object System.Windows.Forms.Label
$lblCredInfo.Text = "Credential: (current user)"
$lblCredInfo.Location = "15,55"
$panelTop.Controls.Add($lblCredInfo)

# OU TreeView row (same sizes/positions)
$lblOU = New-Object System.Windows.Forms.Label
$lblOU.Text = "OU (Tree):"
$lblOU.Location = "15,80"
$panelTop.Controls.Add($lblOU)

$tvOU = New-Object System.Windows.Forms.TreeView
$tvOU.SetBounds(130,85,650,95)
$panelTop.Controls.Add($tvOU)

$btnLoadOUs = New-Object System.Windows.Forms.Button
$btnLoadOUs.Text = "Load OUs"
$btnLoadOUs.SetBounds(840,80,90,26)
$panelTop.Controls.Add($btnLoadOUs)

# ---------------------------
# Controls: Single User
# ---------------------------
$lblSearch = New-Object System.Windows.Forms.Label
$lblSearch.Text = "Search (Name/UPN/SAM):"
$lblSearch.Location = New-Object System.Drawing.Point(15, 25)
$lblSearch.AutoSize = $true
$panelSearch.Controls.Add($lblSearch)

$txtSearch = New-Object System.Windows.Forms.TextBox
$txtSearch.SetBounds(280,22,300,25)
$panelSearch.Controls.Add($txtSearch)

$btnSearch = New-Object System.Windows.Forms.Button
$btnSearch.Text = "Search"
$btnSearch.SetBounds(860,20,90,26)
$panelSearch.Controls.Add($btnSearch)

$dgvUsers = New-Object System.Windows.Forms.DataGridView
$dgvUsers.SetBounds(18,55,1020,120)
$dgvUsers.ReadOnly = $true
$dgvUsers.SelectionMode = 'FullRowSelect'
$dgvUsers.MultiSelect = $false
$dgvUsers.AutoSizeColumnsMode = 'Fill'
$panelSearch.Controls.Add($dgvUsers)

# Password inputs (single-user)
$lblNewPass = New-Object System.Windows.Forms.Label
$lblNewPass.Text = "New Password:"
$lblNewPass.Location = New-Object System.Drawing.Point(18, 225)
$lblNewPass.AutoSize = $true
$panelSearch.Controls.Add($lblNewPass)

$txtNewPass = New-Object System.Windows.Forms.TextBox
$txtNewPass.Location = New-Object System.Drawing.Point(180, 222)
$txtNewPass.Size = New-Object System.Drawing.Size(260, 25)
$txtNewPass.UseSystemPasswordChar = $true
$panelSearch.Controls.Add($txtNewPass)
$txtNewPass.BringToFront() | Out-Null

$lblConfirmPass = New-Object System.Windows.Forms.Label
$lblConfirmPass.Text = "Confirm Password:"
$lblConfirmPass.Location = New-Object System.Drawing.Point(470, 225)
$lblConfirmPass.AutoSize = $true
$panelSearch.Controls.Add($lblConfirmPass)

$txtConfirmPass = New-Object System.Windows.Forms.TextBox
$txtConfirmPass.Location = New-Object System.Drawing.Point(630, 222)
$txtConfirmPass.Size = New-Object System.Drawing.Size(260, 25)
$txtConfirmPass.UseSystemPasswordChar = $true
$panelSearch.Controls.Add($txtConfirmPass)
$txtConfirmPass.BringToFront() | Out-Null

$chkMustChange = New-Object System.Windows.Forms.CheckBox
$chkMustChange.Text = "User must change password at next logon"
$chkMustChange.Location = New-Object System.Drawing.Point(18, 255)
$chkMustChange.AutoSize = $true
$panelSearch.Controls.Add($chkMustChange)

$chkUnlock = New-Object System.Windows.Forms.CheckBox
$chkUnlock.Text = "Unlock account"
$chkUnlock.Location = New-Object System.Drawing.Point(620, 255)
$chkUnlock.AutoSize = $true
$panelSearch.Controls.Add($chkUnlock)

$btnResetSingle = New-Object System.Windows.Forms.Button
$btnResetSingle.Text = "Reset Password (Selected User)"
$btnResetSingle.Location = New-Object System.Drawing.Point(18, 285)
$btnResetSingle.Size = New-Object System.Drawing.Size(280, 30)
$panelSearch.Controls.Add($btnResetSingle)

# ---------------------------
# Controls: Bulk
# ---------------------------
$btnExportCsvTemplate = New-Object System.Windows.Forms.Button
$btnExportCsvTemplate.Text = "Export CSV Template"
$btnExportCsvTemplate.SetBounds(18,25,200,28)
$panelBulk.Controls.Add($btnExportCsvTemplate)

$lblCsv = New-Object System.Windows.Forms.Label
$lblCsv.Text = "Users CSV:"
$lblCsv.Location = "18,65"
$panelBulk.Controls.Add($lblCsv)

$txtCsvPath = New-Object System.Windows.Forms.TextBox
$txtCsvPath.SetBounds(115,62,750,25)
$panelBulk.Controls.Add($txtCsvPath)

$btnBrowseCsv = New-Object System.Windows.Forms.Button
$btnBrowseCsv.Text = "Browse..."
$btnBrowseCsv.SetBounds(890,62,90,26)
$panelBulk.Controls.Add($btnBrowseCsv)

# Replace with single password entry using the SAME coordinates as your old password path field:
$lblSinglePw = New-Object System.Windows.Forms.Label
$lblSinglePw.Text = "Password-same for all users:"
$lblSinglePw.Location = New-Object System.Drawing.Point(18, 95)   # same as old $lblPwd
$lblSinglePw.AutoSize = $true
$panelBulk.Controls.Add($lblSinglePw)

$txtBulkPassword = New-Object System.Windows.Forms.TextBox
$txtBulkPassword.Location = New-Object System.Drawing.Point(280, 95)  # same as old $txtPwdPath
$txtBulkPassword.Size = New-Object System.Drawing.Size(370, 25)       # same width as old path box
$txtBulkPassword.UseSystemPasswordChar = $true
$panelBulk.Controls.Add($txtBulkPassword)

# Button for bulk reset password
$btnResetBulk = New-Object System.Windows.Forms.Button
$btnResetBulk.Text = "Run Bulk Password Reset"
$btnResetBulk.SetBounds(18,130,250,30)
$panelBulk.Controls.Add($btnResetBulk)

$btnExportResults = New-Object System.Windows.Forms.Button
$btnExportResults.Text = "Export Results..."
$btnExportResults.SetBounds(280,130,150,30)
$panelBulk.Controls.Add($btnExportResults)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.SetBounds(18,160,1020,80)
$txtLog.Multiline = $true
$txtLog.ScrollBars = 'Vertical'
$txtLog.ReadOnly = $true
$panelBulk.Controls.Add($txtLog)

# ---------------------------
# Helpers
# ---------------------------
function Add-Log {
    param([string]$Message)
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $txtLog.AppendText("[$ts] $Message`r`n")
}

function Get-SelectedServer {
    if (-not $script:SelectedDomain) { throw "No domain selected." }
    return $script:SelectedDomain
}

# ---------------------------
# Domain & OU Functions
# ---------------------------
function Load-Domains {
    $domains = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Domains |
               ForEach-Object { $_.Name } | Sort-Object
    $cboDomain.Items.Clear()
    [void]$cboDomain.Items.AddRange($domains)
    Add-Log "Loaded domains: $($domains -join ', ')"
}

function Init-OUTree {
    try {
        $domain = Get-SelectedServer
        $dn = (Get-ADDomain -Server $domain).DistinguishedName
        $script:DomainDN = $dn

        $tvOU.BeginUpdate()
        $tvOU.Nodes.Clear()

        $root = New-Object System.Windows.Forms.TreeNode("Entire Domain")
        $root.Tag = $dn
        $tvOU.Nodes.Add($root)

        Get-ADOrganizationalUnit -Filter * -SearchBase $dn -Server $domain | Sort-Object Name | ForEach-Object {
            $node = $root.Nodes.Add($_.Name)
            $node.Tag = $_.DistinguishedName
        }

        $root.Expand()
        $tvOU.EndUpdate()
        Add-Log "Loaded OU tree for $domain"
    } catch {
        Add-Log "OU load failed: $($_.Exception.Message)"
    }
}

# ---------------------------
# User Search & Reset
# ---------------------------
function Search-Users {
    try {
        $domain = Get-SelectedServer
        $query = $txtSearch.Text.Trim()
        if (-not $query) { throw "Enter a search term." }

        $searchBase = if ($tvOU.SelectedNode) { $tvOU.SelectedNode.Tag } else { $script:DomainDN }
        $filter = "(| (samAccountName=$query*)(name=$query*)(userPrincipalName=$query*) )"

        $params = @{
            LDAPFilter = $filter
            SearchBase = $searchBase
            Server = $domain
            Properties = @('displayName','userPrincipalName','enabled','lockedout','distinguishedName')
        }
        if ($script:Credential) { $params.Credential = $script:Credential }

        $users = Get-ADUser @params | Sort-Object Name
        if (-not $users) { Add-Log "No users found."; return }

        # Build DataTable
        $table = New-Object System.Data.DataTable
        "SAM","DisplayName","UPN","Enabled","LockedOut","DN" | ForEach-Object { [void]$table.Columns.Add($_) }
        foreach ($u in $users) {
            $row = $table.NewRow()
            $row.SAM = $u.SamAccountName
            $row.DisplayName = $u.DisplayName
            $row.UPN = $u.UserPrincipalName
            $row.Enabled = $u.Enabled
            $row.LockedOut = $u.LockedOut
            $row.DN = $u.DistinguishedName
            $table.Rows.Add($row)
        }

        $dgvUsers.DataSource = $table
        if ($dgvUsers.Rows.Count -gt 0) {
            $dgvUsers.Rows[0].Selected = $true
            $dgvUsers.CurrentCell = $dgvUsers.Rows[0].Cells[0]
        }
        Add-Log "Found $($users.Count) user(s)."
    } catch {
        Add-Log "Search failed: $($_.Exception.Message)"
    }
}

function Reset-UserPassword {
    param([string]$Sam,[string]$NewPassword,[bool]$MustChange,[bool]$Unlock)
    $domain = Get-SelectedServer
    $secure = ConvertTo-SecureString -AsPlainText $NewPassword -Force
    $params = @{ Server=$domain }
    if ($script:Credential) { $params.Credential = $script:Credential }

    try {
        Set-ADAccountPassword -Identity $Sam -Reset -NewPassword $secure @params
        if ($Unlock) { Unlock-ADAccount -Identity $Sam @params -ErrorAction SilentlyContinue }
        if ($MustChange) { Set-ADUser -Identity $Sam -ChangePasswordAtLogon $true @params }
        return @{ Sam=$Sam; Status="Success"; Message="Password reset OK"; Domain=$domain }
    } catch {
        return @{ Sam=$Sam; Status="Failed"; Message=$_.Exception.Message; Domain=$domain }
    }
}

# ---------------------------
# Bulk Reset
# ---------------------------
function Run-BulkReset {
    try {
        if (-not (Test-Path $txtCsvPath.Text)) { throw "CSV not found." }
        $pw = if ($txtBulkPassword.Text) { $txtBulkPassword.Text } else { $script:DefaultBulkPassword }
        if (-not $pw) { throw "No bulk password provided." }

        $users = Import-Csv $txtCsvPath.Text
        if (-not $users -or $users.Count -eq 0) { throw "CSV is empty or invalid." }

        $script:BulkResults.Clear()
        $count = 0

        foreach ($row in $users) {
            $sam = $row.SamAccountName
            if (-not $sam) {
                Add-Log "Skipped empty SAM in row"
                continue
            }

            $found = $false
            foreach ($domain in @($script:SelectedDomain, "student.lambeth.ac.uk", "lambeth.ac.uk")) {
                try {
                    $params = @{ Identity=$sam; Server=$domain }
                    if ($script:Credential) { $params.Credential = $script:Credential }

                    # Verify user exists
                    $null = Get-ADUser @params -ErrorAction Stop

                    # Reset password
                    $res = Reset-UserPassword -Sam $sam -NewPassword $pw -MustChange $true -Unlock $true
                    $res.Domain = $domain

                    $script:BulkResults.Add([PSCustomObject]$res) | Out-Null
                    Add-Log "[$sam] $($res.Status) in $domain - $($res.Message)"

                    $found = $true
                    break
                } catch {
                    # try next domain
                }
            }

            if (-not $found) {
                $msg = "User not found in any domain"
                $script:BulkResults.Add([PSCustomObject]@{Sam=$sam;Status="Failed";Message=$msg;Domain=$null}) | Out-Null
                Add-Log "[$sam] Failed - $msg"
            }

            $count++
        }

        Add-Log "Bulk reset finished. Processed $count users. Successes: $(@($script:BulkResults | ? { $_.Status -eq 'Success' }).Count), Failures: $(@($script:BulkResults | ? { $_.Status -ne 'Success' }).Count)"
    }
    catch {
        Add-Log "Bulk reset failed: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("Bulk reset failed.`n$($_.Exception.Message)","Bulk Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    }
}

# ---------------------------
# Export
# ---------------------------
function Export-Results {
    if ($script:BulkResults.Count -eq 0) { return }
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = "CSV|*.csv"
    $dlg.FileName = "BulkResults.csv"
    if ($dlg.ShowDialog() -eq "OK") {
        $script:BulkResults | Export-Csv $dlg.FileName -NoTypeInformation -Encoding UTF8
        Add-Log "Exported results to $($dlg.FileName)"
    }
}

# ---------------------------
# Events
# ---------------------------
$btnLoadDomains.Add_Click({ Load-Domains })
$cboDomain.Add_SelectedIndexChanged({
    $script:SelectedDomain = [string]$cboDomain.SelectedItem
    $script:DomainDN = $null
    $tvOU.Nodes.Clear()
    Add-Log "Selected domain: $($script:SelectedDomain)"
})
$chkUseCurrent.Add_CheckedChanged({
    $btnChangeCred.Enabled = -not $chkUseCurrent.Checked
    if ($chkUseCurrent.Checked) { $script:Credential = $null }
})
$btnChangeCred.Add_Click({ $script:Credential = Get-Credential })
$btnLoadOUs.Add_Click({ Init-OUTree })
$btnSearch.Add_Click({ Search-Users })
$btnResetSingle.Add_Click({
    if (-not $dgvUsers.CurrentRow) { return }
    $sam = $dgvUsers.CurrentRow.Cells["SAM"].Value
    $p1 = $txtNewPass.Text; $p2 = $txtConfirmPass.Text
    if ($p1 -ne $p2) { [System.Windows.Forms.MessageBox]::Show("Passwords do not match."); return }
    $res = Reset-UserPassword -Sam $sam -NewPassword $p1 -MustChange $chkMustChange.Checked -Unlock $chkUnlock.Checked
    Add-Log "$($res.Sam): $($res.Status) - $($res.Message)"
})
$btnExportCsvTemplate.Add_Click({ "SamAccountName,DisplayName" | Out-File "UsersTemplate.csv" -Encoding UTF8 })
$btnBrowseCsv.Add_Click({ $dlg=New-Object System.Windows.Forms.OpenFileDialog; $dlg.Filter="CSV|*.csv"; if($dlg.ShowDialog() -eq "OK"){ $txtCsvPath.Text=$dlg.FileName } })
$btnResetBulk.Add_Click({ Run-BulkReset })
$btnExportResults.Add_Click({ Export-Results })

# ---------------------------
# Init
# ---------------------------cd 
Load-Domains
$form.ShowDialog()
